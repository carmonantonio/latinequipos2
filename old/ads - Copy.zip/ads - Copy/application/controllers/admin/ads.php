<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ads extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$user = $this->session->userdata("logged_in");
		if($user!=TRUE){
			//admin folder
			redirect("login");
		}
	}
	
	public function view(){
		$data["ads"] = $this->Ads_Model->view_all();
		$this->load->view("admin/ads/view", $data);
	}

	public function Add(){
		$data["sellers"] = $this->Seller_Model->view_all();
		$data["categories"] = $this->Categories_Model->view_main_cat();
		$data['countries'] = $this->Categories_Model->load_countries();
		$this->load->view('admin/ads/add', $data);
	}
	
	public function insert(){
		
		//print_r($_FILES["userfile1"]); exit;
		$config['upload_path']          = './assets/web/uploads/products/';
		$config['allowed_types']        = 'gif|jpg|png';

		$this->load->library('upload', $config);
		$this->upload->initialize($config);   
		$this->upload->do_upload('userfile1');
		
		$data = array('upload_data' => $this->upload->data());
		$userfile1_name = $data['upload_data']['file_name'];
		$NewImage = base_url().'/assets/web/uploads/products/'.$userfile1_name;
		
		$this->smart_resize_image($NewImage,
                              $string             = null,
                              $width              = 50, 
                              $height             = 50, 
                              $proportional       = false, 
                              $output             = './assets/web/uploads/products/', 
                              $delete_original    = true, 
                              $use_linux_commands = false,
                              $quality            = 100,
                              $grayscale          = false
			 );
		
		/*$config['image_library'] = 'gd2';
		$config['source_image'] = './assets/web/uploads/products/'.$userfile1_name;
		
		$config['maintain_ratio'] = TRUE;
		$config['overwrite'] = TRUE;
		$config['width']         = 600;
		$config['height']       = 400;
		
		$this->load->library('image_lib', $config);
		
		$this->image_lib->resize();
		$this->image_lib->crop();*/
		
		
		
		$cpt = $_FILES['userfile']['name'];
		
		$image_name_uploaded = array();
		foreach($cpt as $key => $value){
			unset($config);
			$config = array();
			$config['upload_path']   = './assets/web/uploads/products/'; 
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size'] = '1000';
			$config['overwrite'] = FALSE;
			$config['remove_spaces'] = FALSE;
			$config['file_name'] = $_FILES['userfile']['name'][$key];
	
			$_FILES['f']['name'] =  $_FILES['userfile']['name'][$key];
			$_FILES['f']['type'] = $_FILES['userfile']['type'][$key];
			$_FILES['f']['tmp_name'] = $_FILES['userfile']['tmp_name'][$key];
			$_FILES['f']['error'] = $_FILES['userfile']['error'][$key];
			$_FILES['f']['size'] = $_FILES['userfile']['size'][$key];
	
			$this->load->library('upload', $config);
			$this->upload->initialize($config);            
			if (! $this->upload->do_upload('f')){
				$data['errors'] = $this->upload->display_errors();
			}else{
				$image_name = $this->upload->data();
				unset($config);
				$config = array();
				$config['image_library']    = 'gd2';
				$config['source_image']     = './assets/web/uploads/products/' . $image_name["file_name"];
				$config['width']            = 600;
				$config['height']           = 600;
		
				$this->load->library('image_lib', $config);
				$this->image_lib->clear();
				$this->image_lib->initialize($config);
				$this->image_lib->resize();
				$types = array('.jpg');	

				$image_name_uploaded[] = $image_name["file_name"];			
			}
		}
		$image_name_uploaded++;
		
		$image_name_uploaded = json_encode($image_name_uploaded);
		
		
		$name 				= $this->input->post("name");
		$seller_id 			= $this->input->post("seller_id");
		$type_of_ad 		= $this->input->post("type_of_ad");
		$country_id 		= $this->input->post("country_id");
		$bodywork 			= $this->input->post("bodywork");
		$mileage 			= $this->input->post("mileage");
		$category_id 		= $this->input->post("category_id");
		$parent_cat 		= $this->input->post("parent_cat");
		$pictures 			= $image_name_uploaded;
		$main_image 		= $userfile1_name;
		$ad_posting_date 	= date("Y-m-d", strtotime($this->input->post("ad_posting_date")));
		$referance 			= $this->input->post("referance");
		$make 				= $this->input->post("make");
		$model 				= $this->input->post("model");
		$status 			= $this->input->post("status");
		$year 				= $this->input->post("year");
		$hours 				= $this->input->post("hours");
		$weight 			= $this->input->post("weight");
		$serial_number 		= $this->input->post("serial_number");
		$first_hand 		= $this->input->post("first_hand");
		$price_excl			= $this->input->post("price_excl");
		$comments 			= json_encode($this->input->post("comments"));
		
		$data = array(
			"name"				=>	$name,
			"type_of_ad"		=>	$type_of_ad,
			"seller_id"			=>	$seller_id,
			"category_id"		=>	$category_id,
			"parent_cat"		=>	$parent_cat,
			"country_id"		=>	$country_id,
			"pictures"			=>	$pictures,
			"main_image"		=>	$main_image,
			"ad_posting_date"	=>	$ad_posting_date,
			"referance"			=>	$referance,
			"make"				=>	$make,
			"model"				=>	$model,
			"status"			=>	$status,
			"year"				=>	$year,
			"hours"				=>	$hours,
			"weight"			=>	$weight,
			"bodywork"			=>	$bodywork,
			"mileage"			=>	$mileage,
			"serial_number"		=>	$serial_number,
			"first_hand"		=>	$first_hand,
			"price_excl"		=>	$price_excl,
			"comments"			=>	$comments,
		);
		
		$status_added = $this->Ads_Model->insert($data);
		if($status_added){
			$this->session->set_flashdata('added_success', 'You have added one Ad successfully');
			redirect("admin/ads/add");
		}else{
			$this->session->set_flashdata('error_occur', 'Some error occured please try again');
			redirect("admin/ads/add");
		}
	}
	
	public function getads($id){
		$data["sellers"] = $this->Seller_Model->view_all();
		$data["categories"] = $this->Categories_Model->view_all();
		$data["ads"] = $this->Ads_Model->getads($id);
		$data['countries'] = $this->Categories_Model->load_countries();
		$this->load->view("admin/ads/edit", $data);
	}
	
	public function load_parent(){
		$id = $this->input->post("id");
		$data['parent_cat'] = $this->Ads_Model->load_parent_by_id($id);
		$this->load->view("admin/ads/parent_cat", $data);
	}
	
	
	function smart_resize_image($file,
                              $string             = null,
                              $width              = 0, 
                              $height             = 0, 
                              $proportional       = false, 
                              $output             = 'file', 
                              $delete_original    = true, 
                              $use_linux_commands = false,
                              $quality            = 100,
                              $grayscale          = false
			 ) {
		  
		if ( $height <= 0 && $width <= 0 ) return false;
		if ( $file === null && $string === null ) return false;
	
		# Setting defaults and meta
		$info                         = $file !== null ? getimagesize($file) : getimagesizefromstring($string);
		$image                        = '';
		$final_width                  = 0;
		$final_height                 = 0;
		list($width_old, $height_old) = $info;
		$cropHeight = $cropWidth = 0;
	
		# Calculating proportionality
		if ($proportional) {
		  if      ($width  == 0)  $factor = $height/$height_old;
		  elseif  ($height == 0)  $factor = $width/$width_old;
		  else                    $factor = min( $width / $width_old, $height / $height_old );
	
		  $final_width  = round( $width_old * $factor );
		  $final_height = round( $height_old * $factor );
		}
		else {
		  $final_width = ( $width <= 0 ) ? $width_old : $width;
		  $final_height = ( $height <= 0 ) ? $height_old : $height;
		  $widthX = $width_old / $width;
		  $heightX = $height_old / $height;
		  
		  $x = min($widthX, $heightX);
		  $cropWidth = ($width_old - $width * $x) / 2;
		  $cropHeight = ($height_old - $height * $x) / 2;
		}
	
		# Loading image to memory according to type
		switch ( $info[2] ) {
		  case IMAGETYPE_JPEG:  $file !== null ? $image = imagecreatefromjpeg($file) : $image = imagecreatefromstring($string);  break;
		  case IMAGETYPE_GIF:   $file !== null ? $image = imagecreatefromgif($file)  : $image = imagecreatefromstring($string);  break;
		  case IMAGETYPE_PNG:   $file !== null ? $image = imagecreatefrompng($file)  : $image = imagecreatefromstring($string);  break;
		  default: return false;
		}
		
		# Making the image grayscale, if needed
		if ($grayscale) {
		  imagefilter($image, IMG_FILTER_GRAYSCALE);
		}    
		
		# This is the resizing/resampling/transparency-preserving magic
		$image_resized = imagecreatetruecolor( $final_width, $final_height );
		if ( ($info[2] == IMAGETYPE_GIF) || ($info[2] == IMAGETYPE_PNG) ) {
		  $transparency = imagecolortransparent($image);
		  $palletsize = imagecolorstotal($image);
	
		  if ($transparency >= 0 && $transparency < $palletsize) {
			$transparent_color  = imagecolorsforindex($image, $transparency);
			$transparency       = imagecolorallocate($image_resized, $transparent_color['red'], $transparent_color['green'], $transparent_color['blue']);
			imagefill($image_resized, 0, 0, $transparency);
			imagecolortransparent($image_resized, $transparency);
		  }
		  elseif ($info[2] == IMAGETYPE_PNG) {
			imagealphablending($image_resized, false);
			$color = imagecolorallocatealpha($image_resized, 0, 0, 0, 127);
			imagefill($image_resized, 0, 0, $color);
			imagesavealpha($image_resized, true);
		  }
		}
		imagecopyresampled($image_resized, $image, 0, 0, $cropWidth, $cropHeight, $final_width, $final_height, $width_old - 2 * $cropWidth, $height_old - 2 * $cropHeight);
		
		
		# Taking care of original, if needed
		if ( $delete_original ) {
		  if ( $use_linux_commands ) exec('rm '.$file);
		  else @unlink($file);
		}
	
		# Preparing a method of providing result
		switch ( strtolower($output) ) {
		  case 'browser':
			$mime = image_type_to_mime_type($info[2]);
			header("Content-type: $mime");
			$output = NULL;
		  break;
		  case 'file':
			$output = $file;
		  break;
		  case 'return':
			return $image_resized;
		  break;
		  default:
		  break;
		}
		
		# Writing image according to type to the output destination and image quality
		switch ( $info[2] ) {
		  case IMAGETYPE_GIF:   imagegif($image_resized, $output);    break;
		  case IMAGETYPE_JPEG:  imagejpeg($image_resized, $output, $quality);   break;
		  case IMAGETYPE_PNG:
			$quality = 9 - (int)((0.9*$quality)/10.0);
			imagepng($image_resized, $output, $quality);
			break;
		  default: return false;
		}
	
		return true;
	  }
	
}