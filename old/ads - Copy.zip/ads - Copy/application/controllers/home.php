<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index(){
		$data['ads'] = $this->Home_Model->load_ads();
		$data['main_cat'] = $this->Home_Model->load_main_cat();
		$this->load->view('web/homepage', $data);
	}
	
	public function search($id){
		$data['ads'] = $this->Home_Model->load_ads_by_id($id);
		$data['main_cat'] = $this->Home_Model->load_main_cat();
		
		$this->load->view('web/search', $data);
	}
	
	public function search_ad($id){
		$data['ad'] = $this->Home_Model->load_ad_by_id($id);
		$this->load->view('web/search_ad', $data);
	}
}
