<?php

function load_parent_cat($id){
	$ci=& get_instance();
	$ci->load->database();
	$ci->db->select('*');
	$ci->db->where('parent_cat', $id);
	$query = $ci->db->get('categories');
	return $query;
}



?>