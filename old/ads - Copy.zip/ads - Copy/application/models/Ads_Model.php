<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Ads_Model extends CI_Model{
	
	public function insert($data){
		$query = $this->db->insert("ads", $data);
		if($query){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	public function view_all(){
		$this->db->select("ad.id, ad.name, ad.seller_id, ad.category_id, sd.name AS seller, c.category_name AS category, ad.type_of_ad, ad.referance, ad.make, ad.model, ad.`status`, ad.year, ad.hours, ad.weight, ad.serial_number, ad.first_hand, ad.bodywork, ad.mileage, ad.price_excl, ad.comments, ad.pictures, ad.ad_posting_date, ad.active");
		$this->db->from("ads AS ad");
		$this->db->join("categories AS c", "c.id = ad.category_id");
		$this->db->join("seller_detail AS sd", "sd.id = ad.seller_id");
		return $this->db->get();
	}
	
	public function getads($id){
		$this->db->where("id", $id);
		$query = $this->db->get("ads");
		return $query->row();
	}
	
	public function load_parent_by_id($id){
		$this->db->where("parent_cat", $id);
		return $this->db->get("categories");
	}
}