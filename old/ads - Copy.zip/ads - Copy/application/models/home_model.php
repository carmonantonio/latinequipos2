<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Home_Model extends CI_Model{
	
	public function load_ads(){
		$this->db->select("ad.id, ad.main_image, ad.name, ad.seller_id, ad.category_id, ad.country_id, cou.name as country, sd.name AS seller, c.category_name AS category, ad.type_of_ad, ad.referance, ad.make, ad.model, ad.`status`, ad.year, ad.hours, ad.weight, ad.serial_number, ad.first_hand, ad.bodywork, ad.mileage, ad.price_excl, ad.comments, ad.pictures, ad.ad_posting_date, ad.active");
		$this->db->from("ads AS ad");
		$this->db->join("categories AS c", "c.id = ad.category_id");
		$this->db->join("countries AS cou", "cou.id = ad.country_id");
		$this->db->join("seller_detail AS sd", "sd.id = ad.seller_id");
		$this->db->order_by("ad.id", "DESC");
		$this->db->limit("5");
		return $this->db->get();
	}
	
	public function load_main_cat(){
		$this->db->where("parent_cat", "0");
		return $this->db->get("categories");
	}
	
	public function load_ads_by_id($id){
		$this->db->select("ad.id, ad.name, ad.seller_id, ad.parent_cat, ad.category_id, cou.name AS country, sd.name AS seller, c.category_name AS category, cat.category_name AS parent_category, ad.type_of_ad, ad.referance, ad.make, ad.model, ad.`status`, ad.year, ad.hours, ad.weight, ad.serial_number, ad.first_hand, ad.bodywork, ad.mileage, ad.price_excl, ad.comments, ad.pictures, ad.ad_posting_date, ad.active");
		$this->db->from("ads AS ad");
		$this->db->join("categories AS c", "c.id = ad.category_id");
		$this->db->join("seller_detail AS sd", "sd.id = ad.seller_id");
		$this->db->join("categories AS cat", "cat.id = ad.parent_cat");
		$this->db->join("countries AS cou", "cou.id = ad.country_id");
		$this->db->where("ad.parent_cat", $id);
		$this->db->order_by("ad.id", "DESC");
		return $this->db->get();
	}
	
	public function load_ad_by_id($id){
		$this->db->select("ad.id, ad.name, ad.seller_id, ad.parent_cat, ad.category_id, cou.name AS country, c.category_name AS category, cat.category_name AS parent_category, sd.name AS seller_name, sd.phone_number AS seller_contact, sd.email AS seller_email, sd.address AS seller_address, sd.occupation AS seller_occupation, sd.description AS seller_description, ad.type_of_ad, ad.referance, ad.make, ad.model, ad.status, ad.year, ad.hours, ad.weight, ad.serial_number, ad.first_hand, ad.bodywork, ad.mileage, ad.price_excl, ad.comments, ad.pictures, ad.ad_posting_date, ad.active");
		$this->db->from("ads AS ad");
		$this->db->join("categories AS c", "c.id = ad.category_id");
		$this->db->join("seller_detail AS sd", "sd.id = ad.seller_id");
		$this->db->join("categories AS cat", "cat.id = ad.parent_cat");
		$this->db->join("countries AS cou", "cou.id = ad.country_id");
		$this->db->where("ad.id", $id);
		$this->db->order_by("ad.id", "DESC");
		$query = $this->db->get();
		return $query->row();
	}
}