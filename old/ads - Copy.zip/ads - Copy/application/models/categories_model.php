<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Categories_Model extends CI_Model{
	
	public function view_main_cat(){
		$this->db->where("parent_cat", "0");
		return $this->db->get("categories");
	}
	
	public function insert($data){
		$query = $this->db->insert("categories", $data);
		if($query){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	public function getcategories($id){
		$this->db->where("id", $id);
		$query = $this->db->get("categories");
		return $query->row();
	}
	
	public function update($id){
		$this->db->set("category_name", $this->input->post("category_name"));
		$this->db->set("parent_cat", $this->input->post("parent_cat"));
		$this->db->where("id", $id);
		$query = $this->db->update("categories");
		if($query){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	public function deletecategories($id){
		$this->db->where("id", $id);
		$query = $this->db->delete("categories");
		if($query){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	public function load_countries(){
		return $this->db->get("countries");
	}
}