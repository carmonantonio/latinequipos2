<?php include(APPPATH."views/admin/inc/header1.php"); ?>
<?php include(APPPATH."views/admin/inc/header2.php"); ?>

<div class="row">
  <div class="col-md-12"> 
    <!-- BEGIN VALIDATION STATES-->
    <div class="portlet light portlet-fit portlet-form ">
      <div class="portlet-title">
        <div class="caption">
          <h3><span class="caption-subject sbold uppercase"><strong>Edit Advertisement</strong></span></h3>
        </div>
      </div>
      <!-- BEGIN FORM-->
      <form action="<?php echo site_url("admin/ads/insert"); ?>" id="form_sample_1" class="form-horizontal" method="post" enctype="multipart/form-data">
        <div class="form-body">
          <div class="alert alert-danger display-hide">
            <button class="close" data-close="alert"></button>
            You have some form errors. Please check below. </div>
          <div class="alert alert-success display-hide">
            <button class="close" data-close="alert"></button>
            Your form validation is successful! </div>
          <?php if($this->session->flashdata('added_success')){ ?>
          <div class="alert alert-success" align="center">
            <button class="close" data-close="alert"></button>
            <?php echo $this->session->flashdata('added_success'); ?> </div>
          <?php } ?>
          <?php if($this->session->flashdata('already_exists')){ ?>
          <div class="alert alert-danger" align="center">
            <button class="close" data-close="alert"></button>
            <?php echo $this->session->flashdata('already_exists'); ?> </div>
          <?php } ?>
          <?php if($this->session->flashdata('error_occur')){ ?>
          <div class="alert alert-danger" align="center">
            <button class="close" data-close="alert"></button>
            <?php echo $this->session->flashdata('error_occur'); ?> </div>
          <?php } ?>
          <div class="form-group">
            <label class="control-label col-md-3">Name <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="name" data-required="1" class="form-control" value="<?php echo $ads->name; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Select Seller<span class="required"> * </span> </label>
            <div class="col-md-4">
              <select class="form-control" name="seller_id">
                <option label="Select Seller"></option>
                <?php if($sellers->num_rows() > 0){ ?>
                <?php foreach($sellers->result() as $sellers){ ?>
                <option value="<?php echo $sellers->id; ?>" <?php if($sellers->id===$ads->seller_id){echo 'selected="selected"'; } ?> ><?php echo $sellers->name; ?></option>
                <?php }} ?>
              </select>
            </div>
            <div class="col-md-3"> <a href="<?php echo site_url("admin/seller/add"); ?>" class="btn btn-default">Add New Seller</a> </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Select Ad Category<span class="required"> * </span> </label>
            <div class="col-md-4">
              <select class="form-control" name="category_id">
                <option label="Select Ad Category"></option>
                <?php if($categories->num_rows() > 0){ ?>
                <?php foreach($categories->result() as $categories){ ?>
                <option value="<?php echo $categories->id; ?>" <?php if($categories->id===$ads->category_id){echo 'selected="selected"'; } ?>><?php echo $categories->category_name; ?></option>
                <?php }} ?>
              </select>
            </div>
            <div class="col-md-3"> <a href="<?php echo site_url("admin/categories/add"); ?>" class="btn btn-default">Add New Category</a> </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Ad Posting Date</label>
            <div class="col-md-4">
              <input class="form-control form-control-inline input-medium date-picker" size="16" type="text" value="<?php echo date("m/d/Y", strtotime($ads->ad_posting_date)); ?>" name="ad_posting_date" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Select Ad Category<span class="required"> * </span> </label>
            <div class="col-md-4">
              <select class="form-control" name="country_id">
                <option label="Select Country"></option>
                <?php if($countries->num_rows() > 0){ ?>
                <?php foreach($countries->result() as $countries){ ?>
                <option value="<?php echo $countries->id; ?>" <?php if($countries->id===$ads->country_id){echo 'selected="selected"';} ?>><?php echo $countries->name; ?></option>
                <?php }} ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Type Of Ad <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="type_of_ad" data-required="1" class="form-control" value="<?php echo $ads->type_of_ad; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Referance <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="referance" data-required="1" class="form-control" value="<?php echo $ads->referance; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Make <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="make" data-required="1" class="form-control" value="<?php echo $ads->make; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Model <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="model" data-required="1" class="form-control" value="<?php echo $ads->model; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Bodywork <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="bodywork" data-required="1" class="form-control" value="<?php echo $ads->bodywork; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Mileage  <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="mileage" data-required="1" class="form-control" value="<?php echo $ads->mileage; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Status <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="status" data-required="1" class="form-control" value="<?php echo $ads->status; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Year <span class="required"> * </span> </label>
            <div class="col-md-4">
              <select class="form-control" name="year">
                <?php for($i=2017; $i>=1920; $i--){ ?>
                <option value="<?php echo $i; ?>" <?php if($i==$ads->year){echo 'selected="selected"'; } ?>><?php echo $i; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Hours <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="hours" data-required="1" class="form-control" value="<?php echo $ads->hours; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Weight <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="weight" data-required="1" class="form-control" value="<?php echo $ads->weight; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Serial Number <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="serial_number" data-required="1" class="form-control" value="<?php echo $ads->serial_number; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">First Hand <span class="required"> * </span> </label>
            <div class="col-md-4">
              <select class="form-control" name="first_hand">
                <option label="---Select---"></option>
                <option value="Yes" <?php if($ads->first_hand=="Yes"){echo 'selected="selected"'; } ?>>Yes</option>
                <option value="No" <?php if($ads->first_hand=="No"){echo 'selected="selected"'; } ?>>No</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Price Excl. <span class="required"> * </span> </label>
            <div class="col-md-4">
              <input type="text" name="price_excl" data-required="1" class="form-control" value="<?php echo $ads->price_excl; ?>" />
            </div>
          </div>
          <div class="form-group">
            <label for="exampleInputFile1"  class="control-label col-md-3">Upload Pictures</label>
            <div class="col-md-4">
              <input type="file" id="exampleInputFile2" name="userfile[]" multiple="multiple">
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Comments <span class="required"> * </span> </label>
            <div class="col-md-4">
              <textarea name="comments" data-required="1" class="form-control" ><?php echo json_decode($ads->comments); ?></textarea>
            </div>
          </div>
        </div>
        <div class="form-actions">
          <div class="row">
            <div class="col-md-offset-3 col-md-9">
              <button type="submit" class="btn green">Submit</button>
              <a href="<?php echo site_url("admin"); ?>" class="btn grey-salsa btn-outline">Cancel</a> </div>
          </div>
        </div>
      </form>
      <!-- END FORM--> 
      
    </div>
    <!-- END VALIDATION STATES--> 
  </div>
</div>
<?php include(APPPATH."views/admin/inc/footer1.php"); ?>
<?php include(APPPATH."views/admin/inc/footer2.php"); ?>
