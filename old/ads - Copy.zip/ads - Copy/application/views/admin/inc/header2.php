</head>
<!-- END HEAD -->

<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
<div class="page-wrapper"> 
  <!-- BEGIN HEADER -->
  <div class="page-header navbar navbar-fixed-top"> 
    <!-- BEGIN HEADER INNER -->
    <?php include(APPPATH."views/admin/inc/top_nav.php"); ?>
    <!-- END HEADER INNER --> 
  </div>
  <!-- END HEADER --> 
  <!-- BEGIN HEADER & CONTENT DIVIDER -->
  <div class="clearfix"> </div>
  <!-- END HEADER & CONTENT DIVIDER --> 
  <!-- BEGIN CONTAINER -->
  <div class="page-container"> 
    <!-- BEGIN SIDEBAR -->
    <?php include(APPPATH."views/admin/inc/sidebar.php"); ?>
    <!-- END SIDEBAR --> 
    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper"> 
      <!-- BEGIN CONTENT BODY -->
      <div class="page-content"> 
        <!-- BEGIN PAGE HEADER--> 
        <!-- BEGIN PAGE BAR -->
        <?php include(APPPATH."views/admin/inc/breadcrumb.php"); ?>
        <!-- END PAGE BAR --> 
        <!-- BEGIN PAGE TITLE-->
        <?php include(APPPATH."views/admin/inc/page_title.php"); ?>
        <!-- END PAGE TITLE--> 
        <!-- END PAGE HEADER-->