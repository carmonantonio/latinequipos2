</div>
      <!-- END CONTENT BODY --> 
    </div>
    <!-- END CONTENT --> 
  </div>
  <!-- END CONTAINER --> 
  <!-- BEGIN FOOTER -->
  <?php include(APPPATH."views/admin/inc/page_footer.php"); ?>
  <!-- END FOOTER --> 
</div>
<!-- BEGIN QUICK NAV -->

<div class="quick-nav-overlay"></div>
<!-- END QUICK NAV --> 
<!--[if lt IE 9]>
<script src="../assets/admin/global/plugins/respond.min.js"></script>
<script src="../assets/admin/global/plugins/excanvas.min.js"></script> 
<script src="../assets/admin/global/plugins/ie8.fix.min.js"></script> 
<![endif]--> 
<!-- BEGIN CORE PLUGINS --> 
<script src="<?php echo base_url(); ?>assets/admin/global/plugins/jquery.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/global/plugins/js.cookie.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/global/plugins/jquery.blockui.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script> 
<!-- END CORE PLUGINS --> 
<!-- BEGIN THEME GLOBAL SCRIPTS --> 
<!-- BEGIN PAGE LEVEL PLUGINS -->
            <script src="<?php echo base_url(); ?>assets/admin/global/scripts/datatable.js" type="text/javascript"></script>
            <script src="<?php echo base_url(); ?>assets/admin/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
            <script src="<?php echo base_url(); ?>assets/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
            <script src="<?php echo base_url(); ?>assets/admin/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
            <!-- END PAGE LEVEL PLUGINS -->
<script src="<?php echo base_url(); ?>assets/admin/global/scripts/app.min.js" type="text/javascript"></script> 
<!-- END THEME GLOBAL SCRIPTS --> 
<!-- BEGIN THEME LAYOUT SCRIPTS --> 
<script src="<?php echo base_url(); ?>assets/admin/layouts/layout/scripts/layout.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/layouts/layout/scripts/demo.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/admin/pages/scripts/table-datatables-buttons.min.js" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->