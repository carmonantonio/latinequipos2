<div class="page-logo"> <a href="index.html"> <img src="<?php echo base_url(); ?>assets/admin/img/logo/logo.png" alt="logo" class="logo-default" /> </a>
        <div class="menu-toggler sidebar-toggler"> <span></span> </div>
      </div>