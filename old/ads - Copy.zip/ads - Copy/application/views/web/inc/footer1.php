<!-- END: PAGE CONTAINER --> 
<!-- BEGIN: LAYOUT/FOOTERS/FOOTER-5 --> 
<a name="footer"></a>
<footer class="c-layout-footer c-layout-footer-3 c-bg-dark">
  <div class="c-prefooter">
    <div class="container">
      <div class="row">
        
        
        <div class="col-md-9" align="center">
        <h1 style="color:white"><strong>Buy and Sell Heavy Machinery on Latinequips</strong></h1>
        <p style="color:#CCC; font-size:14px">Launched in 2003, Latinequips is the European reference classified ad Internet site for the purchase and sale of new and used construction equipment, earthmoving equipment, handling machinery and trucks from industry professionals. Latinequips is a professional platform operating in 16 different languages and also offer classified ads for job vacancies and additional services.>/br> Find the item you are looking for directly from the search engine. Or you could also browse through the different sections of construction equipment, handling/lifting and vehicles/trucks. Are you a seller? Reach Latinequips audience right now! Just a few clicks above and place easily an advert online or discover the Latinequips services tailored to your needs. Farming professionals, Agriaffaires, the twin site, is an Internet site dedicated to the farming sector. </p>
        </div>
        <div class="col-md-3">
          <div class="c-container c-last">
            <div class="c-content-title-1">
              <h3 class="c-font-uppercase c-font-bold c-font-white">Find us</h3>
              <div class="c-line-left hide"></div>
              
            </div>
            
            <ul class="c-address">
              <li> <i class="icon-pointer c-theme-font"></i> One Boulevard, Beverly Hills</li>
              <li> <i class="icon-call-end c-theme-font"></i> +1800 1234 5678</li>
              <li> <i class="icon-envelope c-theme-font"></i> email@example.com</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="c-postfooter">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 c-col" align="center">
          <p class="c-copyright c-font-grey">2017 &copy; Latinequips <span class="c-font-grey-3">All Rights Reserved.</span> </p>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- END: LAYOUT/FOOTERS/FOOTER-5 --> 
<!-- BEGIN: LAYOUT/FOOTERS/GO2TOP -->
<div class="c-layout-go2top"> <i class="icon-arrow-up"></i> </div>
<!-- END: LAYOUT/FOOTERS/GO2TOP --> 
<!-- BEGIN: LAYOUT/BASE/BOTTOM --> 
<!-- BEGIN: CORE PLUGINS --> 
<!--[if lt IE 9]>
	<script src="../<?php echo site_url(); ?>assets/web/global/plugins/excanvas.min.js"></script> 
	<![endif]--> 
<script src="<?php echo site_url(); ?>assets/web/plugins/jquery.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/jquery-migrate.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/jquery.easing.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/reveal-animate/wow.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/base/js/scripts/reveal-animate/reveal-animate.js" type="text/javascript"></script> 
<!-- END: CORE PLUGINS --> 
<!-- BEGIN: LAYOUT PLUGINS --> 
<script src="<?php echo site_url(); ?>assets/web/plugins/revo-slider/js/jquery.themepunch.tools.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/revo-slider/js/jquery.themepunch.revolution.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/revo-slider/js/extensions/revolution.extension.slideanims.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/revo-slider/js/extensions/revolution.extension.layeranimation.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/revo-slider/js/extensions/revolution.extension.navigation.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/revo-slider/js/extensions/revolution.extension.video.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/owl-carousel/owl.carousel.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/plugins/slider-for-bootstrap/js/bootstrap-slider.js" type="text/javascript"></script> 
<!-- END: LAYOUT PLUGINS --> 
<!-- BEGIN: THEME SCRIPTS --> 
<script src="<?php echo site_url(); ?>assets/web/base/js/components.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/base/js/components-shop.js" type="text/javascript"></script> 
<script src="<?php echo site_url(); ?>assets/web/base/js/app.js" type="text/javascript"></script> 
<script>
            $(document).ready(function()
            {
                App.init(); // init core    
            });
        </script> 
<!-- END: THEME SCRIPTS --> 
<!-- BEGIN: PAGE SCRIPTS --> 
<script>
            $(document).ready(function()
            {
                var slider = $('.c-layout-revo-slider .tp-banner');
                var cont = $('.c-layout-revo-slider .tp-banner-container');
                var api = slider.show().revolution(
                {
                    sliderType: "standard",
                    sliderLayout: "fullscreen",
                    responsiveLevels: [2048, 1024, 778, 320],
                    gridwidth: [1240, 1024, 778, 320],
                    gridheight: [868, 768, 960, 720],
                    delay: 15000,
                    startwidth: 1170,
                    startheight: App.getViewPort().height,
                    navigationType: "hide",
                    navigationArrows: "solo",
                    touchenabled: "on",
                    navigation:
                    {
                        keyboardNavigation: "off",
                        keyboard_direction: "horizontal",
                        mouseScrollNavigation: "off",
                        onHoverStop: "on",
                        bullets:
                        {
                            style: "round",
                            enable: true,
                            hide_onmobile: false,
                            hide_onleave: true,
                            hide_delay: 200,
                            hide_delay_mobile: 1200,
                            hide_under: 0,
                            hide_over: 9999,
                            direction: "horizontal",
                            h_align: "right",
                            v_align: "bottom",
                            space: 5,
                            h_offset: 60,
                            v_offset: 60,
                        },
                    },
                    spinner: "spinner2",
                    fullScreenOffsetContainer: '.c-layout-header',
                    shadow: 0,
                    disableProgressBar: "on",
                    hideThumbsOnMobile: "on",
                    hideNavDelayOnMobile: 1500,
                    hideBulletsOnMobile: "on",
                    hideArrowsOnMobile: "on",
                    hideThumbsUnderResolution: 0
                });
            }); //ready
        </script> 
<!-- END: PAGE SCRIPTS --> 
<!-- END: LAYOUT/BASE/BOTTOM -->