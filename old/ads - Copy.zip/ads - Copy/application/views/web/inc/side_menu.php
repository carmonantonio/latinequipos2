<div class="c-layout-sidebar-menu c-theme "> 
    <!-- BEGIN: LAYOUT/SIDEBARS/SHOP-SIDEBAR-MENU-2 -->
    <div class="c-sidebar-menu-toggler">
      <h3 class="c-title c-font-uppercase c-font-bold">Clssified Ads</h3>
      <a href="javascript:;" class="c-content-toggler" data-toggle="collapse" data-target="#sidebar-menu-1"> <span class="c-line"></span> <span class="c-line"></span> <span class="c-line"></span> </a> </div>
    <!-- BEGIN: CONTENT/SHOPS/SHOP-FILTER-SEARCH-1 -->
    <ul class="c-sidebar-menu collapse " id="sidebar-menu-1">
      <li class="c-dropdown c-theme-bg"> <a href="javascript:;" class="c-toggler" style="color:white; text-align:center"><strong>CLASSIFIED ADS</strong></a> </li>
      <?php if($main_cat->num_rows()>0){ ?>
      <?php foreach($main_cat->result() as $main_cat){ ?>
      <li class="c-dropdown"> <a href="javascript:;" class="c-toggler"><?php echo $main_cat->category_name; ?><span class="c-arrow"></span> </a>
        <ul class="c-dropdown-menu">
          <?php
		  $result_parent = load_parent_cat($main_cat->id);
          foreach($result_parent->result() as $parent_cat){ ?>
          <li> <a href="<?php echo site_url("home/search/".$parent_cat->id); ?>"><?php echo $parent_cat->category_name; ?></a> </li>
          <?php } ?>
        </ul>
      </li>
      <?php }} ?>
      <!-- c-active c-open / class="c-active"-->
      
      
      
    </ul>
    
    <!-- END: CONTENT/SHOPS/SHOP-FILTER-SEARCH-1 --> 
    
    <!-- END: LAYOUT/SIDEBARS/SHOP-SIDEBAR-MENU-2 --> 
  </div>