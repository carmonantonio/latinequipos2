</head>
<body class="c-layout-header-fixed c-layout-header-6-topbar">
<!-- BEGIN: LAYOUT/HEADERS/HEADER-2 --> 
<!-- BEGIN: HEADER 2 -->
<header class="c-layout-header c-layout-header-6 c-navbar-fluid" data-minimize-offset="80">
  <div class="c-topbar" style="padding:0px !important">
    <div class="container" align="center"> <img src="<?php echo site_url(); ?>assets/web/img/ads/ad.jpg" alt="Adevertisement" style="width:100%" class="c-desktop-logo-inverse"> 
      <!--<nav class="c-top-menu">
                        <ul class="c-links c-theme-ul">
                            <li>
                                <a href="#">
                                    <i class="icon-social-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="icon-social-facebook"></i>
                                </a>
                            </li>
                            <li class="c-divider"></li>
                            <li>
                                <a href="#">
                                    <i class="icon-social-dribbble"></i>
                                </a>
                            </li>
                            
                        </ul>
                        
                    </nav>-->
      <div class="c-brand">
        <button class="c-topbar-toggler" type="button"> <i class="fa fa-ellipsis-v"></i> </button>
        <button class="c-hor-nav-toggler" type="button" data-target=".c-mega-menu"> <span class="c-line"></span> <span class="c-line"></span> <span class="c-line"></span> </button>
      </div>
    </div>
  </div>
  <div class="c-navbar">
    <div class="container"> 
      <!-- BEGIN: BRAND -->
      <div class="c-navbar-wrapper clearfix"> 
        <!-- END: BRAND --> 
        <!-- BEGIN: QUICK SEARCH --> 
        
        <!-- END: QUICK SEARCH --> 
        <!-- BEGIN: HOR NAV --> 
        <!-- BEGIN: LAYOUT/HEADERS/MEGA-MENU --> 
        <!-- BEGIN: MEGA MENU --> 
        <!-- Dropdown menu toggle on mobile: c-toggler class can be applied to the link arrow or link itself depending on toggle mode -->
        <nav class="c-mega-menu c-pull-right c-mega-menu-dark c-mega-menu-dark-mobile c-fonts-uppercase c-fonts-bold">
          <ul class="nav navbar-nav c-theme-nav">
            <li class="c-menu-type-classic"> <a href="<?php echo site_url(); ?>" class="c-link dropdown-toggle" style="padding:12px 25px 12px 25px !important"><img src="<?php echo site_url(); ?>assets/web/base/img/layout/logos/logo-1.png" alt="Latinequips" class="c-desktop-logo-inverse"> </a> </li>
            <li class="c-active"> <a href="<?php echo site_url(); ?>" class="c-link dropdown-toggle">Home <span class="c-arrow c-toggler"></span> </a> </li>
            <li class="c-menu-type-classic"> <a href="javascript:;" class="c-link dropdown-toggle">Features <span class="c-arrow c-toggler"></span> </a> </li>
          </ul>
        </nav>
        <!-- END: MEGA MENU --> 
        <!-- END: LAYOUT/HEADERS/MEGA-MENU --> 
        <!-- END: HOR NAV --> 
      </div>
      <!-- BEGIN: LAYOUT/HEADERS/QUICK-CART --> 
      <!-- BEGIN: CART MENU -->
      
      <!-- END: CART MENU --> 
      <!-- END: LAYOUT/HEADERS/QUICK-CART --> 
    </div>
  </div>
</header>