<?php include(APPPATH."views/web/inc/header1.php"); ?>
<style>
.owl-item {
	width: 215px !important;
}
.owl-theme .owl-controls {
	margin-top: 0px !important;
}
.owl-theme:not(.owl-single):not(.owl-bordered) .owl-wrapper .owl-item {
	padding: 0 3px !important;
}
.owl-theme:not(.owl-single):not(.owl-bordered) {
	margin-left: 0px !important;
}
</style>
<?php include(APPPATH."views/web/inc/header2.php"); ?>
<!-- END: HEADER 2 -->
<!-- END: LAYOUT/HEADERS/HEADER-2 -->
<!-- BEGIN: CONTENT/USER/FORGET-PASSWORD-FORM -->

<!-- END: CONTENT/USER/FORGET-PASSWORD-FORM -->
<!-- BEGIN: CONTENT/USER/SIGNUP-FORM -->

<!-- END: CONTENT/USER/SIGNUP-FORM -->
<!-- BEGIN: CONTENT/USER/LOGIN-FORM -->

<!-- END: CONTENT/USER/LOGIN-FORM -->
<!-- BEGIN: LAYOUT/SIDEBARS/QUICK-SIDEBAR -->

<!-- END: LAYOUT/SIDEBARS/QUICK-SIDEBAR -->
<!-- BEGIN: PAGE CONTAINER -->

<div class="c-layout-page">
<!-- BEGIN: PAGE CONTENT -->
<div class="container">
  <?php include(APPPATH."views/web/inc/side_menu.php"); ?>
  <div class="c-layout-sidebar-content "> 
    <!-- BEGIN: PAGE CONTENT --> 
    <!-- BEGIN: CONTENT/SHOPS/SHOP-ADVANCED-SEARCH-1 -->
    <?php include(APPPATH."views/web/inc/top_search.php"); ?>
    <style>
    	img.frontimg{max-height:250px;min-height:250px;max-width:250px;min-width:250px;}
    </style>
    <!-- END: CONTENT/SHOPS/SHOP-ADVANCED-SEARCH-1 -->
    <div class="c-margin-t-30"></div>
    <!-- BEGIN: CONTENT/SHOPS/SHOP-RESULT-FILTER-1 -->
    <div class="row">
      <div class="col-md-12"> 
        <!-- Begin: Testimonals 1 component -->
        <div class="c-content-person-1-slider" data-slider="owl" data-items="3" data-auto-play="8000"> 
          <!-- Begin: Title 1 component -->
          <div class="c-content-title-1 wow animated fadeIn">
            <h3 style="margin:0% 0% 1% 0% !important">421,593 construction equipment ads</h3>
          </div>
          <!-- End--> 
          <!-- Begin: Owlcarousel -->
          <div class="row">
            <div class="owl-carousel owl-theme c-theme wow animated fadeInUp">
              <?php foreach($ads->result() as $ads): ?>
              <div class="item">
              <a href="<?php echo site_url("home/search_ad/".$ads->id); ?>">
                <div class="c-content-person-1 c-option-2">
                  <div class="c-caption c-content-overlay">
                  <img src="<?php echo base_url("assets/web/uploads/products/".$ads->main_image); ?>" class="img-responsive c-overlay-object frontimg" alt="">
                    <?php
                    /*$picture = (object)json_decode($ads->pictures);
					foreach($picture as $picture){
						echo '<img src="'.base_url().'assets/web/uploads/products/'.$picture.'" class="img-responsive c-overlay-object" alt="">';
						break;
					}*/
					?>
                  </div>
                  <div class="c-body" style="padding:0px !important">
                    <p> <?php echo $ads->name.' - '.$ads->model.' - '.' <b>$'.number_format($ads->price_excl, 0).'</b> - '.$ads->country; ?> </p>
                  </div>
                </div>
                </a>
              </div>
              <?php endforeach; ?>
              
              <!-- End--> 
            </div>
          </div>
          <!-- End--> 
        </div>
      </div>
      <!-- END: CONTENT/SHOPS/SHOP-RESULT-FILTER-1 -->
      <div class="c-margin-t-20"></div>
      <!-- BEGIN: CONTENT/SHOPS/SHOP-2-8 --> 
      
      <!-- END: PAGE CONTENT --> 
    </div>
  </div>
</div>
<?php include(APPPATH."views/web/inc/footer1.php"); ?>
<script type="text/javascript">

$(document).ready(function(e){
    $('.search-panel .dropdown-menu').find('a').click(function(e) {
    	e.preventDefault();
		var param = $(this).attr("href").replace("#","");
		var concept = $(this).text();
		$('.search-panel span#search_concept').text(concept);
		$('.input-group #search_param').val(param);
	});
});

</script>
<?php include(APPPATH."views/web/inc/footer2.php"); ?>
