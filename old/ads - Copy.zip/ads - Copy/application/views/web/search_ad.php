<?php //echo "<pre>"; print_r($ad); exit; ?>
<?php include(APPPATH."views/web/inc/header1.php"); ?>
<style>
.owl-item {
	width: 215px !important;
}
.owl-theme .owl-controls {
	margin-top: 0px !important;
}
.owl-theme:not(.owl-single):not(.owl-bordered) .owl-wrapper .owl-item {
	padding: 0 3px !important;
}
.owl-theme:not(.owl-single):not(.owl-bordered) {
	margin-left: 0px !important;
}
</style>
<?php include(APPPATH."views/web/inc/header2.php"); ?>
<!-- END: HEADER 2 -->
<!-- END: LAYOUT/HEADERS/HEADER-2 -->
<!-- BEGIN: CONTENT/USER/FORGET-PASSWORD-FORM -->

<!-- END: CONTENT/USER/FORGET-PASSWORD-FORM -->
<!-- BEGIN: CONTENT/USER/SIGNUP-FORM -->

<!-- END: CONTENT/USER/SIGNUP-FORM -->
<!-- BEGIN: CONTENT/USER/LOGIN-FORM -->

<!-- END: CONTENT/USER/LOGIN-FORM -->
<!-- BEGIN: LAYOUT/SIDEBARS/QUICK-SIDEBAR -->

<!-- END: LAYOUT/SIDEBARS/QUICK-SIDEBAR -->
<!-- BEGIN: PAGE CONTAINER -->

<div class="c-layout-page">
<!-- BEGIN: PAGE CONTENT -->
<div class="container">
  <div class="c-layout-sidebar-content ">
    <?php include(APPPATH."views/web/inc/top_search.php"); ?>
    <!-- END: CONTENT/SHOPS/SHOP-ADVANCED-SEARCH-1 -->
    <div class="c-margin-t-30"></div>
    <!-- BEGIN: PAGE CONTENT --> 
    <!-- BEGIN: CONTENT/SHOPS/SHOP-ADVANCED-SEARCH-1 --> 
    
    <!-- END: CONTENT/SHOPS/SHOP-ADVANCED-SEARCH-1 --> 
    
    <!-- BEGIN: CONTENT/SHOPS/SHOP-RESULT-FILTER-1 --> 
    
    <!--<div class="c-shop-result-filter-1 clearfix form-inline">
          <div class="c-filter">
            <label class="control-label c-font-16">Show:</label>
            <select class="form-control c-square c-theme c-input">
              <option value="#?limit=24" selected="selected">24</option>
              <option value="#?limit=25">25</option>
              <option value="#?limit=50">50</option>
              <option value="#?limit=75">75</option>
              <option value="#?limit=100" selected>100</option>
            </select>
          </div>
          <div class="c-filter">
            <label class="control-label c-font-16">Sort&nbsp;By:</label>
            <select class="form-control c-square c-theme c-input">
              <option value="#?sort=p.sort_order&amp;order=ASC" selected="selected">Default</option>
              <option value="#?sort=pd.name&amp;order=ASC">Name (A - Z)</option>
              <option value="#?sort=pd.name&amp;order=DESC">Name (Z - A)</option>
              <option value="#?sort=p.price&amp;order=ASC">Price (Low &gt; High)</option>
              <option value="#?sort=p.price&amp;order=DESC" selected>Price (High &gt; Low)</option>
              <option value="#?sort=rating&amp;order=DESC">Rating (Highest)</option>
              <option value="#?sort=rating&amp;order=ASC">Rating (Lowest)</option>
              <option value="#?sort=p.model&amp;order=ASC">Model (A - Z)</option>
              <option value="#?sort=p.model&amp;order=DESC">Model (Z - A)</option>
            </select>
          </div>
        </div>-->
    
    <div class="c-content-box c-size-lg c-overflow-hide c-bg-white" style="padding:10px 0px !important">
      <div class="c-shop-product-details-2">
        <div class="row">
          <div class="col-md-6">
            <div class="c-product-gallery">
              <div class="c-product-gallery-content">
                <?php
			  $pictures = json_decode($ad->pictures);
              foreach($pictures as $pictures){
			  ?>
                <div class="c-zoom"> <img src="<?php echo site_url("assets/web/uploads/products/".$pictures); ?>"> </div>
                <?php } ?>
                <!--<div class="c-zoom"> <img src="<?php //echo site_url(); ?>assets/web/base/img/content/shop8/35.jpg"> </div>
                <div class="c-zoom"> <img src="<?php //echo site_url(); ?>assets/web/base/img/content/shop8/37.jpg"> </div>
                <div class="c-zoom"> <img src="<?php //echo site_url(); ?>assets/web/base/img/content/shop8/29.jpg"> </div>--> 
              </div>
              <div class="row c-product-gallery-thumbnail">
                <?php
			  $pictures = json_decode($ad->pictures);
              foreach($pictures as $pictures){
			  ?>
                <div class="col-xs-3 c-product-thumb"> <img src="<?php echo site_url("assets/web/uploads/products/".$pictures); ?>"> </div>
                <?php } ?>
                <!--<div class="col-xs-3 c-product-thumb"> <img src="<?php //echo site_url(); ?>assets/web/base/img/content/shop/92.jpg"> </div>
                <div class="col-xs-3 c-product-thumb"> <img src="<?php //echo site_url(); ?>assets/web/base/img/content/shop/02.jpg"> </div>
                <div class="col-xs-3 c-product-thumb c-product-thumb-last"> <img src="<?php //echo site_url(); ?>assets/web/base/img/content/shop/80.jpg"> </div>--> 
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="c-product-meta">
              <div class="c-content-title-1">
                <h3 class="c-font-uppercase c-font-bold">
                  <?php if(!empty($ad->name)){echo $ad->name; } ?>
                </h3>
              </div>
              <div class="c-product-review"> </div>
              <div class="c-product-price">Price: $
                <?php if(!empty($ad->price_excl)){echo number_format($ad->price_excl);} ?>
              </div>
              <?php if(!empty($ad->type_of_ad)){ ?>
              <p> <strong>Type of Ad:</strong>&nbsp;<?php echo $ad->type_of_ad; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->country)){ ?>
              <p> <strong>Country:</strong>&nbsp;<?php echo $ad->country; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->referance)){ ?>
              <p> <strong>Referance:</strong>&nbsp;<?php echo $ad->referance; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->make)){ ?>
              <p> <strong>Make:</strong>&nbsp;<?php echo $ad->make; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->model)){ ?>
              <p> <strong>Model:</strong>&nbsp;<?php echo $ad->model; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->status)){ ?>
              <p> <strong>Status:</strong>&nbsp;<?php echo $ad->status; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->year)){ ?>
              <p> <strong>Year:</strong>&nbsp;<?php echo $ad->year; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->hours)){ ?>
              <p> <strong>Hours:</strong>&nbsp;<?php echo $ad->hours; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->weight)){ ?>
              <p> <strong>Weight:</strong>&nbsp;<?php echo $ad->weight; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->serial_number)){ ?>
              <p> <strong>Serial Number:</strong>&nbsp;<?php echo $ad->serial_number; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->first_hand)){ ?>
              <p> <strong>First Hand:</strong>&nbsp;<?php echo $ad->first_hand; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->bodywork)){ ?>
              <p> <strong>Bodywork:</strong>&nbsp;<?php echo $ad->bodywork; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->mileage)){ ?>
              <p> <strong>Mileage:</strong>&nbsp;<?php echo $ad->mileage; ?> </p>
              <?php } ?>
              <?php if(!empty($ad->comments)){ ?>
              <p> <strong>Comments:</strong>&nbsp;<?php echo json_decode($ad->comments); ?> </p>
              <?php } ?>
            </div>
          </div>
        </div>
        <div class="c-margin-t-60"></div>
        <div class="row">
          <div class="c-content-box c-size-md c-no-padding">
            <div class="c-shop-product-tab-1" role="tabpanel">
              <div class="container">
                <ul class="nav nav-justified" role="tablist">
                  <li role="presentation"> <a class="c-font-uppercase c-font-bold" href="#tab-2" role="tab" data-toggle="tab" style="background-color:#e7505a; ">
                    <h1 style="color:white !important"><strong>Contact Seller</strong></h1>
                    </a> </li>
                </ul>
              </div>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade" id="tab-2">
                  <div class="container">
                    <div class="col-md-offset-3 col-md-3"> <strong>Name:</strong> <?php echo $ad->seller_name; ?> </div>
                    <div class="col-md-6" > <strong>Address:</strong><?php echo $ad->seller_address; ?> </div>
                    <div class="col-md-offset-3 col-md-3" > <strong>Phone Number:</strong> <?php echo $ad->seller_contact; ?> </div>
                    <div class="col-md-6" > <strong>Email:</strong> <?php echo $ad->seller_email; ?> </div>
                    <div class="col-md-offset-3 col-md-3" > <strong>Occupation:</strong> <?php echo $ad->seller_occupation; ?> </div>
                    <div class="col-md-6" > <strong>Description:</strong> <?php echo $ad->seller_description; ?> </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include(APPPATH."views/web/inc/footer1.php"); ?>
<script src="<?php echo site_url(); ?>assets/web/plugins/zoom-master/jquery.zoom.min.js" type="text/javascript"></script> 
<script type="text/javascript">
$(document).ready(function()
            {
                App.init(); // init core    
            });
$(document).ready(function(e){
    $('.search-panel .dropdown-menu').find('a').click(function(e) {
    	e.preventDefault();
		var param = $(this).attr("href").replace("#","");
		var concept = $(this).text();
		$('.search-panel span#search_concept').text(concept);
		$('.input-group #search_param').val(param);
	});
});

</script>
<?php include(APPPATH."views/web/inc/footer2.php"); ?>
