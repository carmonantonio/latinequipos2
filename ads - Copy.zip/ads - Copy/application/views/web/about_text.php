<div class="c-content-box c-size-md c-bg-grey-1">
  <div class="container" style="padding:5% 0% !important;">
    <div class="c-content-bar-1 c-opt-1" >
    <div class="col-md-4" align="center" style="margin-top:5%">
      <img src="<?php echo site_url(); ?>assets/web/base/img/layout/logos/logo-3.png" width="200" />
      </div>
    <div class="col-md-8">
      <h3 class="c-font-uppercase c-font-bold" style="font-size:28px;">Buy and Sell Heavy Machinery on Latinequips</h3>
      <p style="font-size:14px;font-weight:100"> Launched in 2003, Latinequips is the European reference classified ad Internet site for the purchase and sale of new and used construction equipment, earthmoving equipment, handling machinery and trucks from industry professionals. Latinequips is a professional platform operating in 16 different languages and also offer classified ads for job vacancies and additional services.</br></br> Find the item you are looking for directly from the search engine. Or you could also browse through the different sections of construction equipment, handling/lifting and vehicles/trucks. Are you a seller? Reach Latinequips audience right now! Just a few clicks above and place easily an advert online or discover the Latinequips services tailored to your needs. Farming professionals, Agriaffaires, the twin site, is an Internet site dedicated to the farming sector. </p>
      </div>
      
    </div>
  </div>
</div>