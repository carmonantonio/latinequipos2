<!--<div class="hor-menu  hor-menu-light hidden-sm hidden-xs">
        <ul class="nav navbar-nav">
          <li class="classic-menu-dropdown active" aria-haspopup="true"> <a href="index.html"> Active <span class="selected"> </span> </a> </li>
          <li class="classic-menu-dropdown" aria-haspopup="true"> <a href="javascript:;" data-hover="megamenu-dropdown" data-close-others="true"> Classic <i class="fa fa-angle-down"></i> </a>
            <ul class="dropdown-menu pull-left">
              <li> <a href="javascript:;"> <i class="fa fa-bookmark-o"></i> Section 1 </a> </li>
              <li> <a href="javascript:;"> <i class="fa fa-user"></i> Section 2 </a> </li>
            </ul>
          </li>
        </ul>
      </div>
      <form class="search-form" action="extra_search.html" method="GET">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Search..." name="query">
          <span class="input-group-btn"> <a href="javascript:;" class="btn submit"> <i class="icon-magnifier"></i> </a> </span> </div>
      </form>-->