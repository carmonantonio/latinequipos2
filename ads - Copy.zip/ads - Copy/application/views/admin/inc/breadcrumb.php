<div class="page-bar">
          <ul class="page-breadcrumb">
            <li> <a href="index.html">Home</a> <i class="fa fa-circle"></i> </li>
            <li> <span>Horizontal Menu</span> </li>
          </ul>
        </div>