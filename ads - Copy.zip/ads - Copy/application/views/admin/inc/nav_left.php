<div class="page-logo"> <a href="index.html"> <img src="<?php echo site_url(); ?>assets/web/base/img/layout/logos/logo-1.png" style="margin: 8px 0 0 !important;" alt="logo" class="logo-default" /> </a>
        <div class="menu-toggler sidebar-toggler"> <span></span> </div>
      </div>